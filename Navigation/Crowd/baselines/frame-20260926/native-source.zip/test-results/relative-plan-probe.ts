import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {CrowdSimulation} from '../src/core/simulation';
import {ExternalContactSolver} from '../src/core/external-contact-solver';
import {getScenario} from '../src/scenarios/scenarios';
import {scaleScenario} from '../src/scenarios/lab-scenarios';
const data=JSON.parse(gunzipSync(readFileSync('baselines/frame-20260926/rocky-ui-quality.json.gz')).toString());
const row=data.rows.find((r:any)=>r.mode==='wind'&&r.seed===42);
const sim=new CrowdSimulation(row.initial.config,scaleScenario(getScenario(row.scenario),Math.sqrt(row.agents/1000)));
const proto=ExternalContactSolver.prototype as any,original=proto.planSubsteps,scratch=new Int32Array(row.agents),records:any[]=[];
proto.planSubsteps=function(input:any,external:any,minimumRadius:number,maximumSpeed:number,ordinarySpeed:number,absoluteSteps:number){
 const previous=original.call(this,input,external,minimumRadius,maximumSpeed,ordinarySpeed,absoluteSteps),s=input.next,full=maximumSpeed*input.fixedDelta;
 let relativeSquared=0,wallSquared=0,queries=0;
 for(let k=0;k<this.staticCount;k++){const a=this.staticAgents[k];wallSquared=Math.max(wallSquared,4*(s.vx[a]**2+s.vy[a]**2));}
 for(let a=0;a<s.count;a++)if(s.active[a]) {
  const ra=input.agentRadii[a],range=ra+input.maxAgentRadius+input.agentGap+2*full+minimumRadius;
  const n=input.index.queryCandidates(s.x[a],s.y[a],range,scratch);queries+=n;
  for(let k=0;k<n;k++) {
   const b=scratch[k];if(b<=a)continue;
   const dx=s.x[b]-s.x[a],dy=s.y[b]-s.y[a],r=ra+input.agentRadii[b]+input.agentGap,d2=dx*dx+dy*dy;
   if(d2>(r+2*full+minimumRadius)**2)continue;
   const vx=s.vx[b]-s.vx[a],vy=s.vy[b]-s.vy[a];
   if(dx*vx+dy*vy<0||d2<r*r)relativeSquared=Math.max(relativeSquared,vx*vx+vy*vy);
  }
 }
 const proposed=Math.min(absoluteSteps,Math.max(1,Math.ceil(1.5*Math.sqrt(Math.max(relativeSquared,wallSquared))*input.fixedDelta/minimumRadius)));
 records.push({tick:sim.stepCount,previous,proposed,staticCount:this.staticCount,relativeSpeed:Math.sqrt(relativeSquared),staticBound:Math.sqrt(wallSquared),queries});
 return previous;
};
for(let tick=0;tick<660;tick++){for(const e of row.commands)if(e.tick===tick)sim.enqueueExternal(e);sim.step();}
writeFileSync('test-results/issue33-relative-plan-probe.json',JSON.stringify({note:'Read-only candidate-plan instrumentation; production substep selection unchanged. Timing is not a performance result.',records}));
console.log(JSON.stringify({rows:records.length,oldSteps:records.reduce((n,r)=>n+r.previous,0),proposedSteps:records.reduce((n,r)=>n+r.proposed,0),reduced:records.filter(r=>r.proposed<r.previous).length,hash:sim.stateHash()}));
