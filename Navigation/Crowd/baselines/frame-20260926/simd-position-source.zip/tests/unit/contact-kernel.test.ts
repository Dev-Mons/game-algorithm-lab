import { expect, it } from 'vitest';
import { ContactKernel } from '../../src/core/contact-kernel';
import { SpatialHash } from '../../src/algorithms/spatial-hash/spatial-hash';

it('preserves full center-first pair order through mixed radii, inactive bodies and capacity growth',()=>{
  const count=300,grid=new SpatialHash(100,80,12,count),kernel=ContactKernel.create(()=>0,()=>{})!;
  expect(kernel).not.toBeNull();
  const x=new Float64Array(count),y=new Float64Array(count),radii=new Float64Array(count),active=new Uint8Array(count);
  for(let a=0;a<count;a++) {x[a]=(a*37%97)+1;y[a]=(a*19%77)+1;radii[a]=1+a%5;active[a]=a%13?1:0;}
  grid.rebuild(x,y,active);
  const scratch=new Int32Array(count),expectedA:number[]=[],expectedB:number[]=[];
  kernel.ensure(count,32,grid.cellStart.length);
  for(const padding of [0,1,10,64]) {
    expectedA.length=0;expectedB.length=0;let candidates=0,fallbacks=0,ownershipSkips=0;
    for(let a=0;a<count;a++)if(active[a]) {
      const n=grid.queryCandidates(x[a]!,y[a]!,radii[a]!+5+.4+padding,scratch);candidates+=n;if(n>=65)fallbacks++;
      for(let k=0;k<n;k++) {
        const b=scratch[k]!;if(b<=a){ownershipSkips++;continue;}
        const radius=radii[a]!+radii[b]!+.4+padding;
        if((x[b]!-x[a]!)**2+(y[b]!-y[a]!)**2>radius*radius)continue;
        expectedA.push(a);expectedB.push(b);
      }
    }
    let pairs=-1;
    while(pairs<0) {
      const data=kernel.arrays;
      data.x.set(x);data.y.set(y);data.radii.set(radii);data.active.set(active);
      data.cellStart.set(grid.cellStart);data.cellIndices.set(grid.agentIndices);
      pairs=kernel.exports.buildPairs(count,data.a.length,grid.columns,grid.rows,12,5,.4,padding);
      if(pairs<0)kernel.ensure(count,data.a.length*2);
    }
    expect([...kernel.arrays.a.subarray(0,pairs)]).toEqual(expectedA);
    expect([...kernel.arrays.b.subarray(0,pairs)]).toEqual(expectedB);
    expect(kernel.exports.pairCandidates()).toBe(candidates);
    expect(kernel.exports.pairFallbacks()).toBe(fallbacks);
    expect(kernel.exports.pairOwnershipSkips()).toBe(ownershipSkips);
    expect(kernel.arrays.x).toEqual(x);expect(kernel.arrays.y).toEqual(y);
  }
});

it('publishes the latest packed bodies to a static callback and preserves scalar correction bytes',()=>{
  const calls:number[][]=[];
  const kernel=ContactKernel.create(()=>0,(a,b,dx,dy,d,correction)=>{
    const s=kernel!.arrays;calls.push([s.x[a]!,s.x[b]!,dx]);
    const mx=dx/d*correction,my=dy/d*correction;
    s.x[a]=s.x[a]!-mx;s.y[a]=s.y[a]!-my;s.x[b]=s.x[b]!+mx;s.y[b]=s.y[b]!+my;
  })!;
  kernel.ensure(3,2);
  const s=kernel.arrays;s.x.set([10,16,22]);s.y.fill(10);s.radii.fill(3.2);s.active.fill(1);
  s.freeX.set(s.x);s.freeY.set(s.y);s.freeRadius.set([1000,1000,0]);
  s.anchorX.set(s.x);s.anchorY.set(s.y);s.a.set([0,1]);s.b.set([1,2]);
  kernel.exports.packPositions(3);
  kernel.exports.position(2,.4,3.2);
  expect(calls).toEqual([[16+.4,22,22-(16+.4)]]);
  kernel.exports.publishPositions(3);
  expect(s.x).toEqual(new Float64Array([10-.4,16+.4-.4,22+.4]));
  expect(s.y).toEqual(new Float64Array([10,10,10]));
  expect(kernel.exports.maximumDisplacement(3)).toBe(Math.sqrt(Math.max((10-.4-10)**2,(22+.4-22)**2)));
  expect(kernel.exports.hasCompression(2,.45)).toBe(0);
});
