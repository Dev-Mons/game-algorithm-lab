interface Table { keys:Float64Array; values:Float64Array; used:Int32Array; count:number; }
interface Snapshot { keys:Float64Array; values:Float64Array; }
const empty=():Table=>({keys:new Float64Array(0),values:new Float64Array(0),used:new Int32Array(0),count:0});

/** Two reusable open-addressed tables, rebuilt in pair order at each substep.
 * Values are normal impulse, tangent impulse, nx, ny and dt. No per-contact objects. */
export class WarmContactCache {
  private current=empty();
  private previous=empty();
  get values():Float64Array { return this.current.values; }
  get bytes():number { return [this.current,this.previous].reduce((n,t)=>n+t.keys.byteLength+t.values.byteLength+t.used.byteLength,0); }
  get currentTable():Table { return this.current; }
  get previousTable():Table { return this.previous; }
  get capacity():number { return Math.max(this.current.keys.length,this.previous.keys.length); }
  onBuffer(buffer:ArrayBufferLike):boolean { return this.current.keys.buffer===buffer&&this.previous.keys.buffer===buffer; }
  bytesOutside(buffer:ArrayBufferLike|undefined):number {
    let bytes=0;
    for(const t of [this.current,this.previous])for(const view of [t.keys,t.values,t.used])if(view.buffer!==buffer)bytes+=view.byteLength;
    return bytes;
  }
  snapshot():[Snapshot,Snapshot] {
    return [this.current,this.previous].map(t=>{
      const keys=new Float64Array(t.count),values=new Float64Array(t.count*5);
      for(let i=0;i<t.count;i++) {
        const slot=t.used[i]!;keys[i]=t.keys[slot]!;
        values.set(t.values.subarray(slot*5,slot*5+5),i*5);
      }
      return {keys,values};
    }) as [Snapshot,Snapshot];
  }
  /** Rebind after linear-memory growth, rehashing in the original insertion order. */
  bind(current:Omit<Table,'count'>,previous:Omit<Table,'count'>,saved:[Snapshot,Snapshot]):void {
    const tables=[current,previous].map((storage,i)=>{
      const t={...storage,count:saved[i]!.keys.length},snapshot=saved[i]!,mask=t.keys.length-1;t.keys.fill(0);
      for(let n=0;n<t.count;n++) {
        const encoded=snapshot.keys[n]!;let slot=Math.imul(encoded,2654435761)&mask;
        while(t.keys[slot])slot=(slot+1)&mask;
        t.keys[slot]=encoded;t.used[n]=slot;t.values.set(snapshot.values.subarray(n*5,n*5+5),slot*5);
      }
      return t;
    });
    this.current=tables[0]!;this.previous=tables[1]!;
  }
  setNativeCount(count:number):void { this.current.count=count; }

  begin(maximumEntries:number):void {
    const swap=this.previous;this.previous=this.current;this.current=swap;
    let capacity=16;
    while(capacity<maximumEntries*2)capacity*=2;
    if(this.current.keys.length<capacity)this.current={keys:new Float64Array(capacity),values:new Float64Array(capacity*5),used:new Int32Array(capacity),count:0};
    this.current.keys.fill(0);this.current.count=0;
  }

  add(key:number,nx:number,ny:number,dt:number,friction:number):number {
    const encoded=key+1,table=this.current;
    let old=-1;
    if(this.previous.keys.length) {
      const mask=this.previous.keys.length-1;
      let slot=Math.imul(encoded,2654435761)&mask;
      while(this.previous.keys[slot]) {
        if(this.previous.keys[slot]===encoded){old=slot*5;break;}
        slot=(slot+1)&mask;
      }
    }
    const mask=table.keys.length-1;
    let slot=Math.imul(encoded,2654435761)&mask;
    while(table.keys[slot])slot=(slot+1)&mask;
    table.keys[slot]=encoded;table.used[table.count++]=slot;
    const base=slot*5,prior=this.previous.values;
    const cosine=old>=0?prior[old+2]!*nx+prior[old+3]!*ny:0;
    const sine=old>=0?prior[old+2]!*ny-prior[old+3]!*nx:0;
    const scale=old>=0&&cosine>.95?dt/prior[old+4]!:0;
    // Preserve the prior world-space impulse when the contact basis rotates,
    // then project it onto the current friction cone. Rotating a large stored
    // normal impulse blindly can inject substantial tangential kinetic energy.
    const normal=old>=0?Math.max(0,(prior[old]!*cosine-prior[old+1]!*sine)*scale):0;
    const tangent=old>=0?(prior[old]!*sine+prior[old+1]!*cosine)*scale:0;
    table.values[base]=normal;
    table.values[base+1]=Math.max(-friction*normal,Math.min(friction*normal,tangent));
    table.values[base+2]=nx;table.values[base+3]=ny;table.values[base+4]=dt;
    return base;
  }

  reset():void {
    for(const t of [this.current,this.previous])if(t.count){t.count=0;t.keys.fill(0);}
  }

  hashState(mix:(value:number)=>void):void {
    const t=this.current;
    for(let i=0;i<t.count;i++) {
      const slot=t.used[i]!,base=slot*5;
      mix(t.keys[slot]!-1);
      for(let j=0;j<4;j++)mix(Math.round(t.values[base+j]!*1e6));
      mix(Math.round(t.values[base+4]!*1e9));
    }
  }
}
