import { expect, it } from 'vitest';
import { ContactKernel } from '../../src/core/contact-kernel';
import { SpatialHash } from '../../src/algorithms/spatial-hash/spatial-hash';

it('preserves full center-first pair order through mixed radii, inactive bodies and capacity growth',()=>{
  const count=300,grid=new SpatialHash(100,80,12,count),kernel=ContactKernel.create(()=>0,()=>{})!;
  expect(kernel).not.toBeNull();
  const x=new Float64Array(count),y=new Float64Array(count),radii=new Float64Array(count),active=new Uint8Array(count);
  for(let a=0;a<count;a++) {x[a]=(a*37%97)+1;y[a]=(a*19%77)+1;radii[a]=1+a%5;active[a]=a%13?1:0;}
  grid.rebuild(x,y,active);
  const scratch=new Int32Array(count),expectedA:number[]=[],expectedB:number[]=[];
  kernel.ensure(count,32,grid.cellStart.length);
  for(const padding of [0,1,10,64]) {
    expectedA.length=0;expectedB.length=0;let candidates=0,fallbacks=0,ownershipSkips=0;
    for(let a=0;a<count;a++)if(active[a]) {
      const n=grid.queryCandidates(x[a]!,y[a]!,radii[a]!+5+.4+padding,scratch);candidates+=n;if(n>=65)fallbacks++;
      for(let k=0;k<n;k++) {
        const b=scratch[k]!;if(b<=a){ownershipSkips++;continue;}
        const radius=radii[a]!+radii[b]!+.4+padding;
        if((x[b]!-x[a]!)**2+(y[b]!-y[a]!)**2>radius*radius)continue;
        expectedA.push(a);expectedB.push(b);
      }
    }
    let pairs=-1;
    while(pairs<0) {
      const data=kernel.arrays;
      data.x.set(x);data.y.set(y);data.radii.set(radii);data.active.set(active);
      data.cellStart.set(grid.cellStart);data.cellIndices.set(grid.agentIndices);
      pairs=kernel.exports.buildPairs(count,data.a.length,grid.columns,grid.rows,12,5,.4,padding);
      if(pairs<0)kernel.ensure(count,data.a.length*2);
    }
    expect([...kernel.arrays.a.subarray(0,pairs)]).toEqual(expectedA);
    expect([...kernel.arrays.b.subarray(0,pairs)]).toEqual(expectedB);
    expect(kernel.exports.pairCandidates()).toBe(candidates);
    expect(kernel.exports.pairFallbacks()).toBe(fallbacks);
    expect(kernel.exports.pairOwnershipSkips()).toBe(ownershipSkips);
    expect(kernel.arrays.x).toEqual(x);expect(kernel.arrays.y).toEqual(y);
  }
});

it.each([false,true])('resumes the exact ordered suffix when a correction wakes an omitted pair (static callback=%s)',callbacks=>{
  function create() {
    const kernel=ContactKernel.create(()=>0,(a,b,dx,dy,d,correction)=>{
      const s=kernel!.arrays,mx=dx/d*correction,my=dy/d*correction;
      s.x[a]=s.x[a]!-mx;s.y[a]=s.y[a]!-my;s.x[b]=s.x[b]!+mx;s.y[b]=s.y[b]!+my;
      s.corrected[a]=1;s.corrected[b]=1;
      const length=Math.sqrt(mx*mx+my*my);s.lengths[a]=s.lengths[a]!+length;s.lengths[b]=s.lengths[b]!+length;
    })!;
    kernel.ensure(8,7);
    const s=kernel.arrays;s.x.set([100,100.5,101,101.5,102,102.5,104,112.6]);s.y.fill(100);s.radii.fill(3.2);
    s.freeX.fill(100);s.freeY.fill(100);s.freeRadius.fill(callbacks?0:1000);
    s.a.set([0,1,2,3,4,5,6]);s.b.set([6,6,6,6,6,6,7]);return kernel;
  }
  const actual=create(),expected=create();
  const count=actual.exports.buildPositionWorkset(7,8,.4,1.6);
  expect(count).toBe(6);expect([...actual.arrays.positionPairs.subarray(0,count)]).toEqual([0,1,2,3,4,5]);
  expected.exports.position(7,.4,3.2);
  const suffix=actual.exports.positionSubset(count,.4,3.2,.64);
  expect(suffix).toBeGreaterThan(0);expect(suffix).toBeLessThan(7);
  actual.exports.positionSuffix(suffix,7,.4,3.2);
  // The seventh pair was excluded at construction, then became a real contact
  // before its turn in the original sweep. It must move this pass, not next tick.
  expect(actual.arrays.x[7]).toBeGreaterThan(112.6);
  for(const key of ['x','y','corrected','lengths'] as const)expect(actual.arrays[key]).toEqual(expected.arrays[key]);
  expect(actual.exports.validPositionWorkset(8,.64)).toBe(0);
});

it('keeps a valid position subset exact and detects motion by an external constraint',()=>{
  const actual=ContactKernel.create(()=>0,()=>{})!,expected=ContactKernel.create(()=>0,()=>{})!;
  for(const k of [actual,expected]) {
    k.ensure(4,3);const s=k.arrays;s.x.set([10,16.7,40,46.7]);s.y.fill(10);s.radii.fill(3.2);
    s.freeX.fill(30);s.freeY.fill(10);s.freeRadius.fill(100);
    s.a.set([0,1,2]);s.b.set([1,2,3]);
  }
  const count=actual.exports.buildPositionWorkset(3,4,.4,1.6);
  expect(count).toBe(2);
  expect(actual.exports.positionSubset(count,.4,3.2,.64)).toBe(-1);
  expected.exports.position(3,.4,3.2);
  expect(actual.arrays.x).toEqual(expected.arrays.x);
  expect(actual.exports.validPositionWorkset(4,.64)).toBe(1);
  actual.arrays.x[1]=actual.arrays.x[1]!+1;
  expect(actual.exports.validPositionWorkset(4,.64)).toBe(0);
});
