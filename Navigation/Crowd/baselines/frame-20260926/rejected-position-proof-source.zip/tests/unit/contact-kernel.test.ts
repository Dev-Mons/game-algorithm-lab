import { expect, it } from 'vitest';
import { ContactKernel } from '../../src/core/contact-kernel';
import { SpatialHash } from '../../src/algorithms/spatial-hash/spatial-hash';

it('preserves full center-first pair order through mixed radii, inactive bodies and capacity growth',()=>{
  const count=300,grid=new SpatialHash(100,80,12,count),kernel=ContactKernel.create(()=>0,()=>{})!;
  expect(kernel).not.toBeNull();
  const x=new Float64Array(count),y=new Float64Array(count),radii=new Float64Array(count),active=new Uint8Array(count);
  for(let a=0;a<count;a++) {x[a]=(a*37%97)+1;y[a]=(a*19%77)+1;radii[a]=1+a%5;active[a]=a%13?1:0;}
  grid.rebuild(x,y,active);
  const scratch=new Int32Array(count),expectedA:number[]=[],expectedB:number[]=[];
  kernel.ensure(count,32,grid.cellStart.length);
  for(const padding of [0,1,10,64]) {
    expectedA.length=0;expectedB.length=0;let candidates=0,fallbacks=0,ownershipSkips=0;
    for(let a=0;a<count;a++)if(active[a]) {
      const n=grid.queryCandidates(x[a]!,y[a]!,radii[a]!+5+.4+padding,scratch);candidates+=n;if(n>=65)fallbacks++;
      for(let k=0;k<n;k++) {
        const b=scratch[k]!;if(b<=a){ownershipSkips++;continue;}
        const radius=radii[a]!+radii[b]!+.4+padding;
        if((x[b]!-x[a]!)**2+(y[b]!-y[a]!)**2>radius*radius)continue;
        expectedA.push(a);expectedB.push(b);
      }
    }
    let pairs=-1;
    while(pairs<0) {
      const data=kernel.arrays;
      data.x.set(x);data.y.set(y);data.radii.set(radii);data.active.set(active);
      data.cellStart.set(grid.cellStart);data.cellIndices.set(grid.agentIndices);
      pairs=kernel.exports.buildPairs(count,data.a.length,grid.columns,grid.rows,12,5,.4,padding);
      if(pairs<0)kernel.ensure(count,data.a.length*2);
    }
    expect([...kernel.arrays.a.subarray(0,pairs)]).toEqual(expectedA);
    expect([...kernel.arrays.b.subarray(0,pairs)]).toEqual(expectedB);
    expect(kernel.exports.pairCandidates()).toBe(candidates);
    expect(kernel.exports.pairFallbacks()).toBe(fallbacks);
    expect(kernel.exports.pairOwnershipSkips()).toBe(ownershipSkips);
    expect(kernel.arrays.x).toEqual(x);expect(kernel.arrays.y).toEqual(y);
  }
});

it('reuses empty-disk travel proofs without changing pair or static correction arithmetic',()=>{
  const count=80,pairs=count*(count-1)/2;
  function create() {
    let callbacks=0;
    const kernel=ContactKernel.create(()=>0,(a,b,dx,dy,d,correction)=>{
      callbacks++;
      const s=kernel!.arrays,mx=dx/d*correction,my=dy/d*correction;
      s.x[a]=Math.max(3.2,s.x[a]!-mx);s.y[a]=Math.max(3.2,s.y[a]!-my);
      s.x[b]=Math.max(3.2,s.x[b]!+mx);s.y[b]=Math.max(3.2,s.y[b]!+my);
    })!;
    kernel.ensure(count,pairs);const s=kernel.arrays;
    for(let a=0;a<count;a++) {
      s.x[a]=10+(a%10)*5.9;s.y[a]=10+Math.floor(a/10)*5.9;s.radii[a]=3.2+(a%3)*.1;
      s.freeX[a]=s.x[a]!;s.freeY[a]=s.y[a]!;s.freeRadius[a]=a<10?2:100;
    }
    let pair=0;
    for(let a=0;a<count;a++)for(let b=a+1;b<count;b++){s.a[pair]=a;s.b[pair++]=b;}
    return {kernel,callbacks:()=>callbacks};
  }
  const actual=create(),expected=create();let proofs=0;
  for(let i=0;i<10;i++) {
    actual.kernel.exports.position(pairs,.4,3.2,count,3.4);
    // This disables only the new proof; the original exact disk/static path runs.
    expected.kernel.exports.position(pairs,.4,3.2,count,1e9);
    proofs+=actual.kernel.exports.positionStaticProofs();
    for(const key of ['x','y','corrected','lengths'] as const)expect(actual.kernel.arrays[key]).toEqual(expected.kernel.arrays[key]);
    expect(actual.callbacks()).toBe(expected.callbacks());
  }
  expect(proofs).toBeGreaterThan(100);expect(actual.callbacks()).toBeGreaterThan(0);
});
