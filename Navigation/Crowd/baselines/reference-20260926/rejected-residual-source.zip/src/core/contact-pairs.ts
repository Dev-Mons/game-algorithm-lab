import type { SpatialHash } from '../algorithms/spatial-hash/spatial-hash';
import type { AgentBuffer } from './agent-state';

/** Conservative broad phase, owned by the lower body ID.
 * Reads a frozen CSR grid and positions; writes only pair IDs and work counters.
 * Stable cell/ID order is also the reference order for contact coloring.
 * A GPU implementation can count per body, prefix-sum, then fill these columns.
 * Capacity growth never restarts a query or copies simulation state.
 */
export class ContactPairs {
  a = new Int32Array(0);
  b = new Int32Array(0);
  count = 0;
  candidates = 0;
  distanceTests = 0;
  cells = 0;
  ownershipSkips = 0;
  maximumNeighbors = 0;
  get bytes(): number { return this.a.byteLength + this.b.byteLength; }

  build(state: AgentBuffer, grid: SpatialHash, radii: Float64Array | undefined,
    baseRadius: number, maximumRadius: number, gap: number, padding: number, maximumPairs: number): void {
    this.count = 0;
    this.candidates = 0; this.distanceTests = 0; this.cells = 0;
    this.ownershipSkips = 0; this.maximumNeighbors = 0;
    for (let a = 0; a < state.count; a++) {
      if (!state.active[a]) continue;
      const x = state.x[a]!, y = state.y[a]!;
      const range = (radii?.[a] ?? baseRadius) + maximumRadius + gap + padding;
      const minColumn = Math.max(0, Math.floor((x - range) / grid.cellSize));
      const maxColumn = Math.min(grid.columns - 1, Math.floor((x + range) / grid.cellSize));
      const minRow = Math.max(0, Math.floor((y - range) / grid.cellSize));
      const maxRow = Math.min(grid.rows - 1, Math.floor((y + range) / grid.cellSize));
      const column = Math.max(minColumn, Math.min(maxColumn, Math.floor(x / grid.cellSize)));
      const row = Math.max(minRow, Math.min(maxRow, Math.floor(y / grid.cellSize)));
      const rings = Math.max(column - minColumn, maxColumn - column, row - minRow, maxRow - row);
      const before = this.count;
      for (let ring = 0; ring <= rings; ring++) {
        const left = column - ring, right = column + ring, top = row - ring, bottom = row + ring;
        for (let edge = 0; edge < 2; edge++) {
          const y = edge === 0 ? top : bottom;
          if (edge === 0 ? y < minRow : y === top || y > maxRow) continue;
          for (let x = Math.max(left, minColumn); x <= Math.min(right, maxColumn); x++) {
            this.visitCell(state, grid, radii, baseRadius, a, y * grid.columns + x, gap, padding, maximumPairs);
          }
        }
        for (let y = Math.max(top + 1, minRow); y <= Math.min(bottom - 1, maxRow); y++) {
          if (left >= minColumn) this.visitCell(state, grid, radii, baseRadius, a, y * grid.columns + left, gap, padding, maximumPairs);
          if (right !== left && right <= maxColumn) this.visitCell(state, grid, radii, baseRadius, a, y * grid.columns + right, gap, padding, maximumPairs);
        }
      }
      this.maximumNeighbors = Math.max(this.maximumNeighbors, this.count - before);
    }
  }

  private visitCell(state: AgentBuffer, grid: SpatialHash, radii: Float64Array | undefined,
    baseRadius: number, a: number, cell: number, gap: number, padding: number, maximumPairs: number): void {
    const {x,y}=state,{cellStart,agentIndices}=grid;
    const ax=x[a]!,ay=y[a]!,ar=radii?.[a]??baseRadius;
    const start = cellStart[cell]!, end = cellStart[cell + 1]!;
    this.cells++; this.candidates += end - start;
    let count=this.count,checked=0,aa=this.a,bb=this.b;
    for (let slot = start; slot < end; slot++) {
      const b = agentIndices[slot]!;
      // IDs descend within a cell: skip the entire unowned suffix.
      if (b <= a) { this.ownershipSkips += end - slot; break; }
      checked++;
      const dx = x[b]! - ax, dy = y[b]! - ay;
      const radius = ar + (radii?.[b] ?? baseRadius) + gap + padding;
      if (dx * dx + dy * dy > radius * radius) continue;
      if (count === maximumPairs) throw new RangeError('External contact pair budget exceeded; overlapping/overpacked initial state.');
      if (count === aa.length) {
        this.grow(Math.min(maximumPairs,Math.max(32,count*2)));
        aa=this.a;bb=this.b;
      }
      aa[count] = a; bb[count++] = b;
    }
    this.count=count;this.distanceTests+=checked;
  }

  private grow(capacity:number):void {
    const a=new Int32Array(capacity),b=new Int32Array(capacity);
    a.set(this.a);b.set(this.b);this.a=a;this.b=b;
  }
}
