/** One ordered velocity projection pass. All geometry is frozen for the pass.
 * Reads pair geometry, static visibility and the workset; updates vx/vy,
 * accumulated impulses, corrected/affected flags and scalar reductions.
 * Pairs in each ContactColoring range have disjoint endpoints. A GPU port must
 * place a barrier between ranges (or use a separately validated Jacobi reduction).
 * There are no browser, Worker, memory-arena or geometry callbacks here.
 */
export interface ContactVelocityBuffers {
  a: Int32Array; b: Int32Array;
  dx: Float64Array; dy: Float64Array; radius: Float64Array;
  contacts: Int32Array; visible: Int8Array;
  work: Int32Array;
  vx: Float64Array; vy: Float64Array;
  nx: Float64Array; ny: Float64Array;
  normal: Float64Array; tangent: Float64Array;
  quietVX: Float64Array; quietVY: Float64Array;
  corrected: Uint8Array; affected: Uint8Array;
}

export interface ContactVelocityResult {
  constraints: number;
  energyDamped: number;
  maximumImpulse: number;
  skipped: number;
}

export function solveContactVelocity(buffers: ContactVelocityBuffers, count: number,
  dt: number, friction: number, motorSquared: number, residualTolerance: number, result: ContactVelocityResult): void {
  const {a:pairA,b:pairB,dx:pairDX,dy:pairDY,radius,contacts,visible,work,vx,vy,
    nx:normalX,ny:normalY,normal:normalImpulses,tangent:tangentImpulses,quietVX,quietVY,corrected,affected} = buffers;
  result.constraints=0;result.energyDamped=0;result.maximumImpulse=0;result.skipped=0;
  const residualSquared=residualTolerance*residualTolerance;
  const responseBound=.25*(1+friction*friction);
  for(let slot=0;slot<count;slot++) {
    const pair=work[slot]!;
    if(visible[pair]!<0)continue;
    const a=pairA[pair]!,b=pairB[pair]!,rvx=vx[b]!-vx[a]!,rvy=vy[b]!-vy[a]!;
    // A fully projected touching pair is a fixed point. With its normal and
    // pair-owned impulses fixed, the response to changed relative velocity is
    // Lipschitz with bound .5*sqrt(1+friction²). Energy damping only shortens it.
    // Skip only below the SAME residual used to stop a whole velocity pass.
    // Anchors are post-projection, substep-local, and never advanced on a skip:
    // accumulated neighbor/proxy changes therefore wake the pair immediately.
    const dx=rvx-quietVX[pair]!,dy=rvy-quietVY[pair]!;
    const bound=(dx*dx+dy*dy)*responseBound+1e-18;
    if(residualTolerance>0&&bound<residualSquared) {
      result.maximumImpulse=Math.max(result.maximumImpulse,bound);
      result.constraints++;result.skipped++;continue;
    }
    const cached=contacts[pair]!;
    let nx:number,ny:number;
    if(cached>=0) {nx=normalX[pair]!;ny=normalY[pair]!;}
    else {
      let x=pairDX[pair]!,y=pairDY[pair]!;
      const c=x*x+y*y-radius[pair]!*radius[pair]!;
      if(c>1e-6) {
        const dot=x*rvx+y*rvy;
        if(dot>=0||c+2*dot*dt>0)continue;
        const speedSquared=rvx*rvx+rvy*rvy,discriminant=dot*dot-speedSquared*c;
        if(speedSquared<1e-12||discriminant<0)continue;
        const time=(-dot-Math.sqrt(discriminant))/speedSquared;
        if(time<0||time>dt)continue;
        x+=rvx*time;y+=rvy*time;
      }
      const distance=Math.sqrt(x*x+y*y);
      if(distance>1e-9) {nx=x/distance;ny=y/distance;}
      else {
        const angle=((Math.imul(a+1,73856093)^Math.imul(b+1,19349663))>>>0)/4294967296*Math.PI*2;
        nx=Math.cos(angle);ny=Math.sin(angle);
      }
    }
    result.constraints++;
    const closing=rvx*nx+rvy*ny;
    if(closing>=0&&(cached<0||normalImpulses[pair]===0)) {
      if(cached>=0){quietVX[pair]=rvx;quietVY[pair]=rvy;}continue;
    }
    const oldNormal=cached>=0?normalImpulses[pair]!:0;
    let normal=Math.max(0,oldNormal-closing*.5),impulse=normal-oldNormal;
    const tx=-ny,ty=nx,oldTangent=cached>=0?tangentImpulses[pair]!:0;
    let newTangent=Math.max(-normal*friction,Math.min(normal*friction,oldTangent+(rvx*tx+rvy*ty)*.5));
    let tangent=newTangent-oldTangent;
    let damped=false;
    // Releasing a warm friction impulse must not add kinetic energy.
    if(cached>=0&&impulse<0&&Math.abs(oldTangent)>normal*friction) {
      const work=impulse*closing-tangent*(rvx*tx+rvy*ty),length=impulse*impulse+tangent*tangent;
      if(work+length>0&&length>0) {
        const scale=work<0?Math.min(1,-work/(2*length)):0;
        impulse*=scale;tangent*=scale;normal=oldNormal+impulse;newTangent=oldTangent+tangent;
        result.energyDamped++;
        damped=true;
      }
    }
    const squared=impulse*impulse+tangent*tangent;
    result.maximumImpulse=Math.max(result.maximumImpulse,squared);
    if(cached>=0){normalImpulses[pair]=normal;tangentImpulses[pair]=newTangent;}
    quietVX[pair]=NaN;
    if(impulse!==0||tangent!==0) {
      corrected[a]=1;corrected[b]=1;
      vx[a]=vx[a]!-impulse*nx+tangent*tx;vy[a]=vy[a]!-impulse*ny+tangent*ty;
      vx[b]=vx[b]!+impulse*nx-tangent*tx;vy[b]=vy[b]!+impulse*ny-tangent*ty;
      if((affected[a]||affected[b])&&squared>motorSquared){affected[a]=1;affected[b]=1;}
    }
    if(cached>=0&&!damped) {quietVX[pair]=vx[b]!-vx[a]!;quietVY[pair]=vy[b]!-vy[a]!;}
  }
}
